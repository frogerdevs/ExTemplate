﻿global using $safeprojectname$.Interfaces.Repositories.Base;
global using $safeprojectname$.Interfaces.Repositories.Brands;
global using $ext_safeprojectname$.Domain.Entities.Base;
global using $ext_safeprojectname$.Domain.Entities.Brands;
global using MediatR;
global using Microsoft.Extensions.Configuration;
global using Microsoft.Extensions.DependencyInjection;
global using System.Reflection;
