﻿namespace $safeprojectname$.Interfaces.Repositories.Brands
{
    public interface IBrandRepositoryExtendAsync : IBaseRepositoryAsync<Brand, int>
    {
        Task<Brand?> GetByNameAsync(string name);
        Task<Brand?> GetByAsync(Func<Brand, bool> predicate);
    }
}
