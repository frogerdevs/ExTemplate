﻿namespace $safeprojectname$.Extensions.Startup
{
    public class ConfigureExtension
    {

    }
}
