﻿namespace $safeprojectname$.Extensions.Startup
{
    public static class ConfigureServices
    {
        public static IServiceCollection AddDependencyApplication(this IServiceCollection services, 
            IConfiguration configuration)
        {
            services.AddMediatR(Assembly.GetExecutingAssembly());

            return services;

        }
    }
}
