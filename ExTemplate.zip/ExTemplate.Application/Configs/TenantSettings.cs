﻿namespace $safeprojectname$.Configs
{
    public class TenantSettings
    {
        public TenantConnection? Default { get; set; }
        public List<TenantConnection>? TenantConnections { get; set; }
        public string PathFile { get; private set; } = Path.Combine(AppContext.BaseDirectory, "tenantsettings.json");
    }
    public class TenantConnection
    {
        public string? Name { get; set; }
        public string? ConnectionString { get; set; }
    }
}
