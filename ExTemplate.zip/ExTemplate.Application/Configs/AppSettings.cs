﻿namespace $safeprojectname$.Configs
{
    public class AppSettings
    {
        public string AppName { get; set; }
        public Urls Urls { get; set; }
        public string OAuthSwaggerClientId { get; set; }
        public string OAuthSwaggerClientSecret { get; set; }
        public List<string> OAuthSwaggerScopes { get; set; }
        public string UrlAuthority { get; set; }
        public string ResourceClientId { get; set; }
        public string ResourceClientSecret { get; set; }
        public string UrlIssuer { get; set; }
    }
    public class Urls
    {
        public string Core { get; set; }
        public string Ess { get; set; }
        public string Payrol { get; set; }
    }
}
