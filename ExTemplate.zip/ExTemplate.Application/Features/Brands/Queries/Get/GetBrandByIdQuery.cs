﻿namespace $safeprojectname$.Features.Brands.Queries.Get
{
    public class GetBrandByIdQuery : IRequest<GetBrandResponse>
    {
        public int Id { get; set; }
    }
    internal class GetBrandByIdQueryHandler : IRequestHandler<GetBrandByIdQuery, GetBrandResponse>
    {
        IBaseRepositoryAsync<Brand, int> _brandRepo;
        public GetBrandByIdQueryHandler(IBaseRepositoryAsync<Brand, int> brandRepo)
        {
            _brandRepo = brandRepo;
        }
        public async Task<GetBrandResponse?> Handle(GetBrandByIdQuery request, CancellationToken cancellationToken)
        {
            var brands = await _brandRepo.GetByIdAsync(request.Id);
            return brands == null ? null : MapToBrandResponse(brands);
        }

        private GetBrandResponse MapToBrandResponse(Brand brands)
        {
            return new GetBrandResponse
            {
                BrandId = brands.Id,
                BrandCode = brands.BrandCode,
                BrandName = brands.BrandName
            };
        }
    }

}
