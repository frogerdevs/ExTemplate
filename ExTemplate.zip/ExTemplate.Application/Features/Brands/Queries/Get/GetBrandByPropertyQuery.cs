﻿namespace $safeprojectname$.Features.Brands.Queries.Get
{
    public class GetBrandByPropertyQuery : IRequest<GetBrandResponse>
    {
        public string BrandCode { get; set; }
    }
    internal class GetAllBrandExtendQueryHandler : IRequestHandler<GetBrandByPropertyQuery, GetBrandResponse>
    {
        IBrandRepositoryExtendAsync _brandRepo;
        public GetAllBrandExtendQueryHandler(IBrandRepositoryExtendAsync brandRepo)
        {
            _brandRepo = brandRepo;
        }
        public async Task<GetBrandResponse?> Handle(GetBrandByPropertyQuery request, CancellationToken cancellationToken)
        {
            var brand = await _brandRepo.GetByAsync(b => b.BrandCode == request.BrandCode);
            return brand == null ? null : MapToBrandResponse(brand);
        }

        private GetBrandResponse MapToBrandResponse(Brand brands)
        {
            return new GetBrandResponse
            {
                BrandId = brands.Id,
                BrandCode = brands.BrandCode,
                BrandName = brands.BrandName
            };
        }
    }
}
