﻿namespace $safeprojectname$.Features.Brands.Queries.Get
{
    public class GetBrandByNameQuery : IRequest<GetBrandResponse>
    {
        public int Id { get; set; }
        public string BrandName { get; set; }
    }
    internal class GetBrandByNameQueryHandler : IRequestHandler<GetBrandByNameQuery, GetBrandResponse>
    {
        IBrandRepositoryExtendAsync _brandRepo;
        public GetBrandByNameQueryHandler(IBrandRepositoryExtendAsync brandRepo)
        {
            _brandRepo = brandRepo;
        }
        public async Task<GetBrandResponse?> Handle(GetBrandByNameQuery request, CancellationToken cancellationToken)
        {
            var brandbyname = await _brandRepo.GetByNameAsync(request.BrandName);
            return brandbyname == null ? null : MapToBrandResponse(brandbyname);
        }

        private GetBrandResponse MapToBrandResponse(Brand brands)
        {
            return new GetBrandResponse
            {
                BrandId = brands.Id,
                BrandCode = brands.BrandCode,
                BrandName = brands.BrandName
            };
        }
    }

}
