﻿namespace $safeprojectname$.Features.Brands.Queries.Get
{
    public class GetBrandResponse
    {
        public int BrandId { get; set; }
        public string? BrandCode { get; set; }
        public string? BrandName { get; set; }

    }
}
