﻿namespace $safeprojectname$.Features.Brands.Queries.Get
{
    public class GetAllBrandQuery : IRequest<List<GetBrandResponse>>
    {

    }
    internal class GetAllBrandQueryHandler : IRequestHandler<GetAllBrandQuery, List<GetBrandResponse>>
    {
        IBaseRepositoryAsync<Brand, int> _brandRepo;
        public GetAllBrandQueryHandler(IBaseRepositoryAsync<Brand, int> brandRepo)
        {
            _brandRepo = brandRepo;
        }
        public async Task<List<GetBrandResponse>> Handle(GetAllBrandQuery request, CancellationToken cancellationToken)
        {
            var brands = await _brandRepo.GetAllAsync();
            return MapToBrandResponse(brands);
        }

        private List<GetBrandResponse> MapToBrandResponse(List<Brand> brands)
        {
            return brands.ConvertAll(brand => new GetBrandResponse
            {
                BrandId = brand.Id,
                BrandCode = brand.BrandCode,
                BrandName = brand.BrandName
            });
        }
    }
}
