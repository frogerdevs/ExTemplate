﻿namespace $safeprojectname$.Features.Brands.Commands.Delete
{
    public class DeleteBrandCommand : IRequest<int>
    {
        public int Id { get; set; }
    }

    internal class DeleteBrandCommandHandler : IRequestHandler<DeleteBrandCommand, int>
    {
        IBrandRepositoryExtendAsync _brandRepo;

        public DeleteBrandCommandHandler(IBrandRepositoryExtendAsync brandrepo)
        {
            _brandRepo = brandrepo;
        }

        public async Task<int> Handle(DeleteBrandCommand command, CancellationToken cancellationToken)
        {
            var brand = await _brandRepo.GetByIdAsync(command.Id);
            if (brand != null)
            {
                try
                {
                    await _brandRepo.DeleteAsync(brand);
                    return brand.Id;
                }
                catch (Exception)
                {
                    throw;
                }
            }
            else
            {
                return 0;
            }

        }
    }
}
