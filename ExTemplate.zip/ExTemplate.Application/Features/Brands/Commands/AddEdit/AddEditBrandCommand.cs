﻿namespace $safeprojectname$.Features.Brands.Commands.AddEdit
{
    public class AddEditBrandCommand : IRequest<Brand>
    {
        public int BrandId { get; set; }
        public string? BrandCode { get; set; }
        public string? BrandName { get; set; }
    }
    internal class AddEditBrandCommandHandler : IRequestHandler<AddEditBrandCommand, Brand>
    {
        IBaseRepositoryAsync<Brand, int> _brandRepo;

        public AddEditBrandCommandHandler(IBaseRepositoryAsync<Brand, int> brandRepo)
        {
            _brandRepo = brandRepo;
        }

        public async Task<Brand> Handle(AddEditBrandCommand command, CancellationToken cancellationToken)
        {
            if (command.BrandId == 0)
            {
                var brand = MapToBrand(command);
                var res = await _brandRepo.AddAsync(brand);
                
                return res;
            }
            else
            {
                var brand = await _brandRepo.GetByIdAsync(command.BrandId);
                if (brand != null)
                {
                    brand.BrandCode = command.BrandCode ?? brand.BrandCode;
                    brand.BrandName = command.BrandName ?? brand.BrandName;
                    var res = await _brandRepo.UpdateAsync(brand);
                    return res;
                }
                else
                {
                    return null;
                }
            }
        }

        private Brand MapToBrand(AddEditBrandCommand command)
        {
            return new Brand
            {
                Id  =command.BrandId,
                BrandCode = command.BrandCode,
                BrandName = command.BrandName
            };
        }
    }

}
