﻿namespace $safeprojectname$.Extensions.Startup
{
    public static class ConfigureExtension
    {
        public  static void UseDependencyInfrastructure(this IApplicationBuilder app)
        {
            #region Ensure Create DB When Start
            using (var scope = app.ApplicationServices.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetRequiredService<ApiDBContext>();
                dbContext.Database.EnsureCreated();
            }
            #endregion
        }
    }
}
