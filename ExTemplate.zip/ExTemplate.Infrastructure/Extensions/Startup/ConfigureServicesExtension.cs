﻿namespace $safeprojectname$.Extensions.Startup
{
    public static class ConfigureServicesExtension
    {
        public static IServiceCollection AddDependencyInfrastructure(this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddDbContext<ApiDBContext>();
            services.AddScoped(typeof(IBaseRepositoryAsync<,>), typeof(BaseRepositoryAsync<,>));
            services.AddScoped(typeof(IBrandRepositoryExtendAsync), typeof(BrandRepositoryExtendAsync));

            return services;

        }

    }
}
