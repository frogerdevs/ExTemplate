﻿namespace $safeprojectname$.Data.Mappings
{
    public class BrandMap : IEntityTypeConfiguration<Brand>
    {
        public void Configure(EntityTypeBuilder<Brand> builder)
        {
            builder.ToTable("Brand", "sample");

            builder.HasKey(x => new { x.Id }); 

            builder.Property(x => x.Id)
                .HasColumnName("BrandId")
                .ValueGeneratedOnAdd();
        }
    }
}
