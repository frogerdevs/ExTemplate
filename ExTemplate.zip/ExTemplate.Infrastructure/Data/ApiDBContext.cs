﻿namespace $safeprojectname$.Data
{
    public class ApiDBContext : DbContext
    {
        #region Property
        private HttpContext? _httpContext;
        private string _tenantName = "Sample";
        private TenantSettings _tenantSettings;
        #endregion
        #region DBSet
        public DbSet<Brand>? Employees { get; set; }
        #endregion
        public ApiDBContext(DbContextOptions<ApiDBContext> options,
            IOptions<TenantSettings> tenantsettings, IHttpContextAccessor contextAccessor) : base(options)
        {
            _tenantSettings = tenantsettings.Value;
            _httpContext = contextAccessor.HttpContext;
            if (_httpContext != null)
            {
                if (_httpContext.Request.Headers.TryGetValue("tenant", out var tenantId))
                {
                    _tenantName = tenantId;
                }
                else
                {
                    //var routeValues = _httpContext.Request.RouteValues.TryGetValue("id", out var id);
                    throw new Exception("Invalid Tenant!");
                }
            }
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string constring = _tenantSettings.Default.ConnectionString.Replace("{tenant}", _tenantName);
            var tenant = _tenantSettings.TenantConnections.FirstOrDefault(x => x.Name == _tenantName);
            if (tenant != null)
                constring = tenant.ConnectionString;

            optionsBuilder.UseNpgsql(constring);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            #region Mapping
            modelBuilder.ApplyConfiguration(new BrandMap());

            #endregion
        }
    }
}
