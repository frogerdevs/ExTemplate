﻿namespace $safeprojectname$.Repositories.Base
{
    public class BaseRepositoryAsync<T, TId> : IBaseRepositoryAsync<T, TId> where T : class, IBaseEntity<TId> // BaseEntity<TId>
    {
        private readonly ApiDBContext _dbContext;
        public BaseRepositoryAsync(ApiDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IQueryable<T> Entities => _dbContext.Set<T>();

        public async Task<T> AddAsync(T entity)
        {
            await _dbContext.Set<T>().AddAsync(entity);
            await SaveAsync();
            return entity;
        }

        public async Task<T> DeleteAsync(T entity)
        {
            _dbContext.Set<T>().Remove(entity);
            await SaveAsync();
            return entity;
        }

        public async Task<List<T>> GetAllAsync()
        {
            return await _dbContext
                .Set<T>()
                .ToListAsync();
        }

        public async Task<T> GetByIdAsync(TId id)
        {
            return await _dbContext.Set<T>().FindAsync(id);
        }

        public async Task<List<T>> GetPagedResponseAsync(int pageNumber, int pageSize)
        {
            return await _dbContext
                .Set<T>()
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<T> UpdateAsync(T entity)
        {
            T exist = await _dbContext.Set<T>().FindAsync(entity.Id);
            _dbContext.Entry(exist).CurrentValues.SetValues(entity);
            await SaveAsync();
            return entity;
        }
        private async Task SaveAsync(CancellationToken token = default)
        {
            await _dbContext.SaveChangesAsync(token);
        }
    }
}
