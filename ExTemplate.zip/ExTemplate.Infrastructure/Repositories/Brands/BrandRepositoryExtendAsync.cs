﻿namespace $safeprojectname$.Repositories.Brands
{
    public class BrandRepositoryExtendAsync : BaseRepositoryAsync<Brand, int>, IBrandRepositoryExtendAsync
    {
        public BrandRepositoryExtendAsync(ApiDBContext dbContext) : base(dbContext)
        {
        }

        public Task<Brand?> GetByNameAsync(string name)
        {
            var brand = Entities.Where(r => r.BrandName == name).FirstOrDefault();
            return Task.FromResult(brand);
        }
        public Task<Brand?> GetByAsync(Func<Brand, bool> predicate)
        {
            var brand = Entities.Where(predicate).SingleOrDefault();
            return Task.FromResult(brand);
        }
    }
}
