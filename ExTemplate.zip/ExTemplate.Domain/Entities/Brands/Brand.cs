﻿namespace $safeprojectname$.Entities.Brands
{
    public class Brand : BaseAuditableEntity<int>
    {
        public string? BrandCode { get; set; }
        public string? BrandName { get; set; }
    }
}
