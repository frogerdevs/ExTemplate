﻿namespace $safeprojectname$.Entities.Base
{
    public interface IBaseEntity<TId> : IBaseEntity
    {
        public TId Id { get; set; }
    }
    public interface IBaseEntity
    {

    }
}
