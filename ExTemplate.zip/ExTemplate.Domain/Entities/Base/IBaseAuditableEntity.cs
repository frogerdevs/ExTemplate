﻿namespace $safeprojectname$.Entities.Base
{
    public interface IBaseAuditableEntity<TId> : IAuditableEntity, IBaseEntity<TId>
    {
    }
    public interface IAuditableEntity : IBaseEntity
    {
        string? CreatedBy { get; set; }

        DateTime? CreatedOn { get; set; }

        string? LastModifiedBy { get; set; }

        DateTime? LastModifiedOn { get; set; }
    }
}
