﻿global using $safeprojectname$.Entities.Base;
