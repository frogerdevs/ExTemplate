var builder = WebApplication.CreateBuilder(args);
builder.Host.ConfigureAppConfiguration((app, cb) =>
{
    var env = app.HostingEnvironment;
    cb.AddJsonFile("tenantsettings.json", optional: false, reloadOnChange: true);
    cb.AddJsonFile($"tenantsettings.{env.EnvironmentName}.json", optional: false, reloadOnChange: true);
    cb.AddJsonFile($"tenantsettings.{env.EnvironmentName}.json", optional: false, reloadOnChange: true);
});

var startup = new Startup(builder.Configuration);

startup.ConfigureServices(builder.Services);

var app = builder.Build();

var loggerFactory = app.Services.GetRequiredService<ILoggerFactory>();
startup.Configure(app, app.Environment);

await app.RunAsync();