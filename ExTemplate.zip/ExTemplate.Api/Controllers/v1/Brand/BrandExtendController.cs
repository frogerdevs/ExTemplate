﻿
namespace $safeprojectname$.Controllers.v1.Brand
{
    [ApiVersion("1.0")]
    public class BrandExtendController : BaseApiController<BrandController>
    {
        public BrandExtendController()
        {

        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetBrandResponse>>> Get()
        {
            var res = await _mediator.Send(new GetAllBrandQuery());
            return Ok(res);
        }

        [HttpGet("[action]/{name}")]
        public async Task<ActionResult<GetBrandResponse>> GetByName(string name)
        {
            var res = await _mediator.Send(new GetBrandByNameQuery() { BrandName = name});
            if(res==null)
                return NotFound();
            return Ok(res);
        }
        [HttpGet("[action]/{code}")]
        public async Task<ActionResult<GetBrandResponse>> GetByCode(string code)
        {
            var res = await _mediator.Send(new GetBrandByPropertyQuery() { BrandCode  = code });
            if (res == null)
                return NotFound();
            return Ok(res);
        }

    }
}
