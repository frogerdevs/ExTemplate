﻿namespace $safeprojectname$.Controllers.v1.Brand
{
    [ApiVersion("1.0")]
    public class BrandController : BaseApiController<BrandController>
    {
        public BrandController()
        {

        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GetBrandResponse>>> Get()
        {
            var res = await _mediator.Send(new GetAllBrandQuery());
            return Ok(res);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<GetBrandResponse>> Get(int id)
        {
            var res = await _mediator.Send(new GetBrandByIdQuery() { Id = id});
            if(res==null)
                return NotFound();
            return Ok(res);
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] AddEditBrandCommand request)
        {
            if (request == null)
                BadRequest();
            try
            {
                var res = await _mediator.Send(request);
                return new ObjectResult(res) { StatusCode = StatusCodes.Status201Created };
            }
            catch (Exception ex)
            {
                return new ObjectResult(ex) { StatusCode = StatusCodes.Status500InternalServerError };
            }
        }

        // PUT api/<SampleController>/5
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] AddEditBrandCommand request)
        {
            if (id == 0 || request == null)
                return BadRequest();
            try
            {
                var res = await _mediator.Send(request);
                return NoContent();
            }
            catch (Exception ex)
            {
                return new ObjectResult(ex) { StatusCode = StatusCodes.Status500InternalServerError };
            }
        }

        // DELETE api/<SampleController>/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            if (id == 0)
                return BadRequest();

            try
            {
                var brand = await _mediator.Send(new DeleteBrandCommand { Id = id });
                if (brand == 0)
                    return NotFound();

                return NoContent();
            }
            catch (Exception ex)
            {
                return new ObjectResult(ex) { StatusCode = StatusCodes.Status500InternalServerError };
            }
        }
    }
}
