﻿namespace $safeprojectname$.Controllers.v1.WeatherForeCast
{
    [ApiVersion("1.0")]
    public class WeatherForecastController : BaseApiController<WeatherForecastController>
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet()]
        public async Task<ActionResult<IEnumerable<GetAllWeatherResponse>>> Get()
        {
            var res = await _mediator.Send(new GetAllWeatherQuery());
            return Ok(res);
        }
    }
}
