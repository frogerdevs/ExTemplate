﻿
namespace $safeprojectname$.Extensions.Startup
{
    public static class ConfigureServicesExtension
    {
        public static IServiceCollection AddCustomAuthentication(this IServiceCollection services, AppSettings appSettings)
        {
            services.AddAuthentication(OpenIddictValidationAspNetCoreDefaults.AuthenticationScheme);
            services.AddOpenIddict()
                    .AddValidation(options =>
                    {
                        // Note: the validation handler uses OpenID Connect discovery
                        // to retrieve the address of the introspection endpoint.
                        options.SetIssuer(appSettings.UrlIssuer);
                        options.AddAudiences(appSettings.ResourceClientId);

                        // Configure the validation handler to use introspection and register the client
                        // credentials used when communicating with the remote introspection endpoint.
                        options.UseIntrospection()
                               .SetClientId(appSettings.ResourceClientId)
                               .SetClientSecret(appSettings.ResourceClientSecret);

                        // Register the System.Net.Http integration.
                        options.UseSystemNetHttp();

                        // Register the ASP.NET Core host.
                        options.UseAspNetCore();
                    });

            services.AddAuthorization();

            return services;
        }

    }
}
