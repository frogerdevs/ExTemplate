﻿namespace $safeprojectname$
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public AppSettings AppSettings { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            var appSettings = configuration.GetSection(nameof(AppSettings));
            AppSettings = appSettings.Get<AppSettings>();
        }
        public void ConfigureServices(IServiceCollection services)
        {
            #region Inject Configuration
            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));
            services.Configure<TenantSettings>(Configuration.GetSection("TenantSettings"));
            #endregion
            #region Extension
            services.AddHttpContextAccessor();
            services.AddOptions();
            services.AddApiVersion();
            services.AddHealthChecks();
            services.AddSwagger(AppSettings);

            services.AddControllers();
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });

            //services.AddCustomAuthentication(AppSettings);

            services.AddDependencyApplication(Configuration);
            services.AddDependencyInfrastructure(Configuration);
            #endregion
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            #region Ensure Create DB When Start
            app.UseDependencyInfrastructure();
            #endregion
            if (env.IsDevelopment())
            {
                var verprovider = app.ApplicationServices.GetRequiredService<IApiVersionDescriptionProvider>();
                app.ConfigureSwagger(verprovider, AppSettings);
            }
            else if (env.IsProduction())
            {
                var verprovider = app.ApplicationServices.GetRequiredService<IApiVersionDescriptionProvider>();
                app.ConfigureSwagger(verprovider, AppSettings);
                app.UseHsts();
                app.UseHttpsRedirection();
            }
            app.UseRouting();
            app.UseCors("CorsPolicy");
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/health");
            });
        }
    }
}
